# 🚀 Quick Start Guide

Follow these simple steps to get the Employee Attendance System running on your computer.

## ✅ Step-by-Step Setup (For Beginners)

### 1️⃣ Install Required Software

#### Install Node.js
1. Go to https://nodejs.org/
2. Download the **LTS version** (recommended)
3. Run the installer and follow the prompts
4. After installation, open Command Prompt (Windows) or Terminal (Mac/Linux)
5. Type: `node --version` and press Enter
6. You should see a version number like `v18.x.x` or `v20.x.x`

#### Install MongoDB
1. Go to https://www.mongodb.com/try/download/community
2. Download **MongoDB Community Server**
3. Run the installer with default settings
4. MongoDB will start automatically as a service

#### Install Git (Optional but recommended)
1. Go to https://git-scm.com/downloads
2. Download and install Git
3. Follow the installer prompts

### 2️⃣ Download the Project

**Option A: If you have the project as a ZIP file**
1. Extract the ZIP file to a folder (e.g., `C:\Projects\attendance-system`)

**Option B: If you have Git installed**
```bash
git clone <repository-url>
cd attendance-system
```

### 3️⃣ Setup Backend

Open Command Prompt or Terminal and run:

```bash
# Navigate to backend folder
cd backend

# Install all required packages (this may take a few minutes)
npm install

# Create sample data in database
npm run seed

# Start the backend server
npm run dev
```

✅ **Success!** You should see: `Server running in development mode on port 5000`

**Keep this terminal window open!**

### 4️⃣ Setup Frontend

Open a **NEW** Command Prompt or Terminal window and run:

```bash
# Navigate to frontend folder
cd frontend

# Install all required packages (this may take a few minutes)
npm install

# Start the frontend application
npm start
```

✅ **Success!** Your browser should automatically open to `http://localhost:3000`

**Keep this terminal window open too!**

### 5️⃣ Login and Test

The application should now be running in your browser!

**Try the Manager Account:**
- Email: `manager@company.com`
- Password: `manager123`

**Try an Employee Account:**
- Email: `alice@company.com`
- Password: `password123`

## 📋 Common Issues and Solutions

### Issue: "MongoDB connection error"
**Solution:** 
- Make sure MongoDB is installed
- On Windows, it should start automatically
- On Mac, run: `brew services start mongodb-community`
- On Linux, run: `sudo systemctl start mongod`

### Issue: "Port 5000 already in use"
**Solution:**
- Another application is using port 5000
- Close that application or change the PORT in `backend/.env` file
- Change `PORT=5000` to `PORT=5001`

### Issue: "Port 3000 already in use"
**Solution:**
- When prompted, type `Y` to run on a different port

### Issue: "npm: command not found"
**Solution:**
- Node.js is not installed properly
- Reinstall Node.js from nodejs.org
- Restart your computer and try again

### Issue: Packages taking too long to install
**Solution:**
- This is normal for first-time installation
- Wait for it to complete (5-10 minutes)
- Make sure you have a stable internet connection

## 🎯 What to Do Next

1. **As Employee:**
   - Click "Mark Attendance"
   - Click "Check In"
   - Explore your dashboard
   - View your attendance history

2. **As Manager:**
   - View team dashboard
   - Check who's present today
   - Export attendance reports
   - View team calendar

## 🛑 Stopping the Application

To stop the application:
1. Go to the terminal windows
2. Press `Ctrl + C` (Windows/Linux) or `Cmd + C` (Mac)
3. Do this for both backend and frontend terminals

## 🔄 Restarting the Application

To start again later:

**Terminal 1:**
```bash
cd backend
npm run dev
```

**Terminal 2:**
```bash
cd frontend
npm start
```

## 📞 Need Help?

If you're stuck:
1. Make sure you followed all steps in order
2. Check that Node.js and MongoDB are installed
3. Make sure both terminals are open and running
4. Try restarting your computer
5. Delete `node_modules` folders and run `npm install` again

## ✨ Tips for Beginners

- **Two terminals must run simultaneously** - One for backend, one for frontend
- **Don't close the terminal windows** while using the app
- **Backend runs on port 5000**, frontend on port 3000
- **Sample data is created** when you run `npm run seed`
- **You can reset data** anytime by running `npm run seed` again

---

**You're all set! Enjoy using the Attendance System! 🎉**
