# Employee Attendance System

A full-stack web application for managing employee attendance with separate interfaces for employees and managers.

## 🎯 Features

### Employee Features
- ✅ Register/Login
- ⏰ Mark daily attendance (Check In / Check Out)
- 📅 View attendance history (calendar or table view)
- 📊 View monthly summary (Present/Absent/Late days)
- 📈 Personal dashboard with statistics

### Manager Features
- 🔐 Login with manager credentials
- 👥 View all employees' attendance
- 🔍 Filter by employee, date, status, department
- 📊 View team attendance summary
- 📥 Export attendance reports (CSV)
- 📈 Dashboard with team statistics and charts

## 🛠️ Tech Stack

### Frontend
- React 18
- Redux Toolkit (State Management)
- React Router (Navigation)
- Recharts (Charts)
- React Calendar (Calendar View)
- Axios (API Calls)

### Backend
- Node.js
- Express.js
- MongoDB (Database)
- Mongoose (ODM)
- JWT (Authentication)
- bcryptjs (Password Hashing)

## 📋 Prerequisites

Before you begin, ensure you have the following installed:
- **Node.js** (v14 or higher) - [Download](https://nodejs.org/)
- **MongoDB** (Community Edition) - [Download](https://www.mongodb.com/try/download/community)
- **Git** - [Download](https://git-scm.com/downloads)

## 🚀 Installation & Setup

### Step 1: Clone the Repository
```bash
git clone <your-repo-url>
cd attendance-system
```

### Step 2: Backend Setup

1. Navigate to the backend folder:
```bash
cd backend
```

2. Install dependencies:
```bash
npm install
```

3. Create `.env` file (already provided):
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/attendance-system
JWT_SECRET=attendance_system_secret_key_2024
NODE_ENV=development
```

4. Start MongoDB:
- **Windows**: MongoDB should start automatically as a service
- **Mac/Linux**: Run `sudo systemctl start mongod` or `brew services start mongodb-community`

5. Seed the database with sample data:
```bash
npm run seed
```

6. Start the backend server:
```bash
npm run dev
```

The backend will run on `http://localhost:5000`

### Step 3: Frontend Setup

1. Open a new terminal and navigate to the frontend folder:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the frontend development server:
```bash
npm start
```

The frontend will run on `http://localhost:3000` and automatically open in your browser.

## 👤 Demo Accounts

After seeding the database, you can use these accounts:

### Manager Account
- **Email**: manager@company.com
- **Password**: manager123

### Employee Accounts
- **Email**: alice@company.com | **Password**: password123
- **Email**: bob@company.com | **Password**: password123
- **Email**: carol@company.com | **Password**: password123
- **Email**: david@company.com | **Password**: password123
- **Email**: emma@company.com | **Password**: password123

## 📱 Application Pages

### Employee Pages
1. **Login/Register** - Authentication
2. **Dashboard** - Overview of attendance stats
3. **Mark Attendance** - Check in/out for the day
4. **My Attendance** - View personal attendance history
5. **Profile** - View account information

### Manager Pages
1. **Login** - Authentication
2. **Dashboard** - Team statistics and charts
3. **All Attendance** - View and filter all employees' attendance
4. **Team Calendar** - Real-time view of today's attendance
5. **Reports** - Export attendance data to CSV
6. **Profile** - View account information

## 🗄️ Database Schema

### Users Collection
```javascript
{
  name: String,
  email: String (unique),
  password: String (hashed),
  role: String (employee/manager),
  employeeId: String (unique),
  department: String,
  createdAt: Date
}
```

### Attendance Collection
```javascript
{
  userId: ObjectId (ref: User),
  date: Date,
  checkInTime: Date,
  checkOutTime: Date,
  status: String (present/absent/late/half-day),
  totalHours: Number,
  createdAt: Date
}
```

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user

### Attendance (Employee)
- `POST /api/attendance/checkin` - Check in
- `POST /api/attendance/checkout` - Check out
- `GET /api/attendance/my-history` - Get my attendance history
- `GET /api/attendance/my-summary` - Get monthly summary
- `GET /api/attendance/today` - Get today's status

### Attendance (Manager)
- `GET /api/attendance/all` - Get all employees' attendance
- `GET /api/attendance/employee/:id` - Get specific employee's attendance
- `GET /api/attendance/summary` - Get team summary
- `GET /api/attendance/today-status` - Get today's team status
- `GET /api/attendance/export` - Export to CSV

### Dashboard
- `GET /api/dashboard/employee` - Employee dashboard stats
- `GET /api/dashboard/manager` - Manager dashboard stats

## 📸 Features Overview

### Attendance Rules
- Standard work hours: 9:00 AM - 6:00 PM
- Check-in after 9:30 AM is marked as "Late"
- Less than 4 hours of work is marked as "Half Day"
- Each employee can check in/out only once per day

### Status Types
- **Present** - On time (before 9:30 AM)
- **Late** - Checked in after 9:30 AM
- **Half Day** - Worked less than 4 hours
- **Absent** - Did not check in

## 🎨 Screenshots

(Add screenshots of your application here)

## 🐛 Troubleshooting

### MongoDB Connection Error
- Ensure MongoDB is running: `sudo systemctl status mongod`
- Check if the MongoDB URI in `.env` is correct

### Port Already in Use
- Backend: Change PORT in `.env` file
- Frontend: The app will prompt you to use a different port

### Dependencies Installation Error
- Delete `node_modules` and `package-lock.json`
- Run `npm install` again

## 📝 Development Notes

### Running Both Servers
You need to run both backend and frontend simultaneously:

**Terminal 1 (Backend):**
```bash
cd backend
npm run dev
```

**Terminal 2 (Frontend):**
```bash
cd frontend
npm start
```

### Creating New Employees
Use the Register page or the seed script to create new employees.

### Resetting Database
```bash
cd backend
npm run seed
```
This will clear existing data and create fresh sample data.

## 🏗️ Project Structure

```
attendance-system/
├── backend/
│   ├── config/
│   │   └── database.js
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── attendanceController.js
│   │   └── dashboardController.js
│   ├── middleware/
│   │   └── auth.js
│   ├── models/
│   │   ├── User.js
│   │   └── Attendance.js
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── attendanceRoutes.js
│   │   └── dashboardRoutes.js
│   ├── .env
│   ├── server.js
│   ├── seedData.js
│   └── package.json
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Sidebar.js
│   │   │   └── PrivateRoute.js
│   │   ├── pages/
│   │   │   ├── Login.js
│   │   │   ├── Register.js
│   │   │   ├── EmployeeDashboard.js
│   │   │   ├── ManagerDashboard.js
│   │   │   ├── MarkAttendance.js
│   │   │   ├── MyAttendance.js
│   │   │   ├── AllAttendance.js
│   │   │   ├── TeamCalendar.js
│   │   │   ├── Reports.js
│   │   │   └── Profile.js
│   │   ├── redux/
│   │   │   ├── store.js
│   │   │   ├── authSlice.js
│   │   │   └── attendanceSlice.js
│   │   ├── services/
│   │   │   └── api.js
│   │   ├── App.js
│   │   ├── App.css
│   │   └── index.js
│   └── package.json
└── README.md
```

## 🤝 Contributing

Feel free to fork this project and submit pull requests.

## 📄 License

This project is open source and available under the MIT License.

## 👨‍💻 Author

Created as a full-stack MERN application project.

## 🙏 Acknowledgments

- React team for the amazing framework
- MongoDB for the database
- Express.js for the backend framework
- All open-source contributors

---

**Happy Coding! 🚀**
