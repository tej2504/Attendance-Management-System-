const Attendance = require('../models/Attendance');
const User = require('../models/User');

// Helper function to get start and end of day
const getStartAndEndOfDay = (date) => {
  const start = new Date(date);
  start.setHours(0, 0, 0, 0);
  const end = new Date(date);
  end.setHours(23, 59, 59, 999);
  return { start, end };
};

// @desc    Get employee dashboard stats
// @route   GET /api/dashboard/employee
// @access  Private (Employee)
exports.getEmployeeDashboard = async (req, res) => {
  try {
    const today = new Date();
    const { start: todayStart, end: todayEnd } = getStartAndEndOfDay(today);

    // Get today's status
    const todayAttendance = await Attendance.findOne({
      userId: req.user._id,
      date: { $gte: todayStart, $lte: todayEnd }
    });

    // Get current month data
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59, 999);

    const monthAttendance = await Attendance.find({
      userId: req.user._id,
      date: { $gte: monthStart, $lte: monthEnd }
    });

    // Calculate monthly stats
    const monthlyStats = {
      present: monthAttendance.filter(a => a.status === 'present').length,
      late: monthAttendance.filter(a => a.status === 'late').length,
      halfDay: monthAttendance.filter(a => a.status === 'half-day').length,
      totalHours: monthAttendance.reduce((sum, a) => sum + a.totalHours, 0).toFixed(2)
    };

    // Get last 7 days attendance
    const sevenDaysAgo = new Date(today);
    sevenDaysAgo.setDate(today.getDate() - 7);

    const recentAttendance = await Attendance.find({
      userId: req.user._id,
      date: { $gte: sevenDaysAgo, $lte: todayEnd }
    }).sort({ date: -1 });

    res.status(200).json({
      success: true,
      data: {
        todayStatus: todayAttendance,
        monthlyStats,
        recentAttendance
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get manager dashboard stats
// @route   GET /api/dashboard/manager
// @access  Private (Manager)
exports.getManagerDashboard = async (req, res) => {
  try {
    const today = new Date();
    const { start: todayStart, end: todayEnd } = getStartAndEndOfDay(today);

    // Total employees
    const totalEmployees = await User.countDocuments({ role: 'employee' });

    // Today's attendance
    const todayAttendance = await Attendance.find({
      date: { $gte: todayStart, $lte: todayEnd }
    }).populate('userId', 'name email employeeId department');

    const todayStats = {
      present: todayAttendance.length,
      absent: totalEmployees - todayAttendance.length,
      late: todayAttendance.filter(a => a.status === 'late').length
    };

    // Get list of absent employees today
    const presentUserIds = todayAttendance.map(a => a.userId._id.toString());
    const allEmployees = await User.find({ role: 'employee' });
    const absentEmployees = allEmployees.filter(
      emp => !presentUserIds.includes(emp._id.toString())
    );

    // Weekly attendance trend (last 7 days)
    const sevenDaysAgo = new Date(today);
    sevenDaysAgo.setDate(today.getDate() - 7);

    const weeklyData = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      const { start, end } = getStartAndEndOfDay(date);

      const dayAttendance = await Attendance.find({
        date: { $gte: start, $lte: end }
      });

      weeklyData.push({
        date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        present: dayAttendance.filter(a => a.status === 'present' || a.status === 'late').length,
        late: dayAttendance.filter(a => a.status === 'late').length,
        absent: totalEmployees - dayAttendance.length
      });
    }

    // Department-wise attendance (current month)
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59, 999);

    const departments = await User.distinct('department', { role: 'employee' });
    const departmentStats = [];

    for (const dept of departments) {
      const deptUsers = await User.find({ department: dept, role: 'employee' });
      const deptUserIds = deptUsers.map(u => u._id);

      const deptAttendance = await Attendance.find({
        userId: { $in: deptUserIds },
        date: { $gte: monthStart, $lte: monthEnd }
      });

      departmentStats.push({
        department: dept,
        employees: deptUsers.length,
        attendance: deptAttendance.length,
        avgAttendance: (deptAttendance.length / (deptUsers.length || 1)).toFixed(1)
      });
    }

    res.status(200).json({
      success: true,
      data: {
        totalEmployees,
        todayStats,
        absentEmployees,
        lateArrivals: todayAttendance.filter(a => a.status === 'late'),
        weeklyTrend: weeklyData,
        departmentStats
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
