const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const dotenv = require('dotenv');
const User = require('./models/User');
const Attendance = require('./models/Attendance');

dotenv.config();

const users = [
  {
    name: 'John Manager',
    email: 'manager@company.com',
    password: 'manager123',
    role: 'manager',
    employeeId: 'MGR001',
    department: 'Management'
  },
  {
    name: 'Alice Johnson',
    email: 'alice@company.com',
    password: 'password123',
    role: 'employee',
    employeeId: 'EMP001',
    department: 'Engineering'
  },
  {
    name: 'Bob Smith',
    email: 'bob@company.com',
    password: 'password123',
    role: 'employee',
    employeeId: 'EMP002',
    department: 'Engineering'
  },
  {
    name: 'Carol Williams',
    email: 'carol@company.com',
    password: 'password123',
    role: 'employee',
    employeeId: 'EMP003',
    department: 'Marketing'
  },
  {
    name: 'David Brown',
    email: 'david@company.com',
    password: 'password123',
    role: 'employee',
    employeeId: 'EMP004',
    department: 'Sales'
  },
  {
    name: 'Emma Davis',
    email: 'emma@company.com',
    password: 'password123',
    role: 'employee',
    employeeId: 'EMP005',
    department: 'Engineering'
  }
];

const generateAttendanceData = (userId, daysBack) => {
  const attendanceRecords = [];
  const today = new Date();

  for (let i = 0; i < daysBack; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    
    // Skip weekends
    if (date.getDay() === 0 || date.getDay() === 6) continue;

    // Random attendance pattern (90% present, 5% late, 5% absent)
    const random = Math.random();
    
    if (random > 0.05) { // 95% attendance
      const checkInHour = random > 0.10 ? 9 : 10; // 90% on time, 5% late
      const checkInMinute = Math.floor(Math.random() * 30);
      const checkInTime = new Date(date);
      checkInTime.setHours(checkInHour, checkInMinute, 0, 0);

      const checkOutHour = 17 + Math.floor(Math.random() * 2); // 5-7 PM
      const checkOutMinute = Math.floor(Math.random() * 60);
      const checkOutTime = new Date(date);
      checkOutTime.setHours(checkOutHour, checkOutMinute, 0, 0);

      const totalHours = Number(((checkOutTime - checkInTime) / (1000 * 60 * 60)).toFixed(2));
      
      let status = 'present';
      if (checkInHour > 9 || (checkInHour === 9 && checkInMinute > 30)) {
        status = 'late';
      }
      if (totalHours < 4) {
        status = 'half-day';
      }

      attendanceRecords.push({
        userId,
        date,
        checkInTime,
        checkOutTime,
        status,
        totalHours
      });
    }
  }

  return attendanceRecords;
};

const seedData = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('MongoDB Connected');

    // Clear existing data
    await User.deleteMany();
    await Attendance.deleteMany();
    console.log('Existing data cleared');

    // Hash passwords and create users
    const createdUsers = [];
    for (const user of users) {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(user.password, salt);
      
      const newUser = await User.create({
        ...user,
        password: hashedPassword
      });
      
      createdUsers.push(newUser);
      console.log(`User created: ${newUser.name} (${newUser.email})`);
    }

    // Generate attendance for employees (last 30 days)
    const employees = createdUsers.filter(u => u.role === 'employee');
    for (const employee of employees) {
      const attendanceRecords = generateAttendanceData(employee._id, 30);
      await Attendance.insertMany(attendanceRecords);
      console.log(`Generated ${attendanceRecords.length} attendance records for ${employee.name}`);
    }

    console.log('\n✅ Seed data created successfully!');
    console.log('\n📋 Login Credentials:');
    console.log('\nManager Account:');
    console.log('Email: manager@company.com');
    console.log('Password: manager123');
    console.log('\nEmployee Accounts:');
    console.log('Email: alice@company.com | Password: password123');
    console.log('Email: bob@company.com | Password: password123');
    console.log('Email: carol@company.com | Password: password123');
    console.log('Email: david@company.com | Password: password123');
    console.log('Email: emma@company.com | Password: password123');

    process.exit(0);
  } catch (error) {
    console.error('Error seeding data:', error);
    process.exit(1);
  }
};

seedData();
