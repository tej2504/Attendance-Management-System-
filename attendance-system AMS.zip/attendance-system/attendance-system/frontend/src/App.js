import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import './App.css';

// Components
import Sidebar from './components/Sidebar';
import PrivateRoute from './components/PrivateRoute';

// Pages
import Login from './pages/Login';
import Register from './pages/Register';
import EmployeeDashboard from './pages/EmployeeDashboard';
import ManagerDashboard from './pages/ManagerDashboard';
import MarkAttendance from './pages/MarkAttendance';
import MyAttendance from './pages/MyAttendance';
import AllAttendance from './pages/AllAttendance';
import TeamCalendar from './pages/TeamCalendar';
import Reports from './pages/Reports';
import Profile from './pages/Profile';

function App() {
  const { user } = useSelector((state) => state.auth);

  return (
    <Router>
      <div className="app-container">
        {user && <Sidebar />}
        <div className={user ? 'main-content' : ''}>
          <Routes>
            {/* Public Routes */}
            <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <Login />} />
            <Route path="/register" element={user ? <Navigate to="/dashboard" /> : <Register />} />

            {/* Private Routes - Dashboard */}
            <Route
              path="/dashboard"
              element={
                <PrivateRoute>
                  {user?.role === 'manager' ? <ManagerDashboard /> : <EmployeeDashboard />}
                </PrivateRoute>
              }
            />

            {/* Employee Routes */}
            <Route
              path="/mark-attendance"
              element={
                <PrivateRoute role="employee">
                  <MarkAttendance />
                </PrivateRoute>
              }
            />
            <Route
              path="/my-attendance"
              element={
                <PrivateRoute role="employee">
                  <MyAttendance />
                </PrivateRoute>
              }
            />

            {/* Manager Routes */}
            <Route
              path="/all-attendance"
              element={
                <PrivateRoute role="manager">
                  <AllAttendance />
                </PrivateRoute>
              }
            />
            <Route
              path="/team-calendar"
              element={
                <PrivateRoute role="manager">
                  <TeamCalendar />
                </PrivateRoute>
              }
            />
            <Route
              path="/reports"
              element={
                <PrivateRoute role="manager">
                  <Reports />
                </PrivateRoute>
              }
            />

            {/* Common Routes */}
            <Route
              path="/profile"
              element={
                <PrivateRoute>
                  <Profile />
                </PrivateRoute>
              }
            />

            {/* Redirect root to dashboard or login */}
            <Route path="/" element={<Navigate to={user ? "/dashboard" : "/login"} />} />

            {/* 404 */}
            <Route path="*" element={<Navigate to={user ? "/dashboard" : "/login"} />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
