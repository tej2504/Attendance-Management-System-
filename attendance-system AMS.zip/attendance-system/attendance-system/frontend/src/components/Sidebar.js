import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../redux/authSlice';

const Sidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.auth);

  const handleLogout = () => {
    dispatch(logout());
    navigate('/login');
  };

  const employeeLinks = [
    { path: '/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/mark-attendance', label: 'Mark Attendance', icon: '✓' },
    { path: '/my-attendance', label: 'My Attendance', icon: '📅' },
    { path: '/profile', label: 'Profile', icon: '👤' },
  ];

  const managerLinks = [
    { path: '/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/all-attendance', label: 'All Attendance', icon: '📋' },
    { path: '/team-calendar', label: 'Team Calendar', icon: '📅' },
    { path: '/reports', label: 'Reports', icon: '📈' },
    { path: '/profile', label: 'Profile', icon: '👤' },
  ];

  const links = user?.role === 'manager' ? managerLinks : employeeLinks;

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h3>⏰ Attendance</h3>
      </div>

      <div className="sidebar-user">
        <h4>{user?.name}</h4>
        <p>{user?.email}</p>
        <span className="user-badge">{user?.role}</span>
      </div>

      <nav className="sidebar-nav">
        {links.map((link) => (
          <Link
            key={link.path}
            to={link.path}
            className={`nav-item ${location.pathname === link.path ? 'active' : ''}`}
          >
            <span className="nav-icon">{link.icon}</span>
            {link.label}
          </Link>
        ))}
      </nav>

      <div className="sidebar-footer">
        <button className="btn btn-danger" onClick={handleLogout} style={{ width: '100%' }}>
          Logout
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
