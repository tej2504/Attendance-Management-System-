import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getAllAttendance } from '../redux/attendanceSlice';

const AllAttendance = () => {
  const dispatch = useDispatch();
  const { attendance, isLoading } = useSelector((state) => state.attendance);

  const [filters, setFilters] = useState({
    employeeId: '',
    status: '',
    startDate: '',
    endDate: '',
    department: '',
  });

  useEffect(() => {
    dispatch(getAllAttendance(filters));
  }, [dispatch]);

  const handleFilterChange = (e) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value,
    });
  };

  const handleSearch = (e) => {
    e.preventDefault();
    dispatch(getAllAttendance(filters));
  };

  const handleReset = () => {
    setFilters({
      employeeId: '',
      status: '',
      startDate: '',
      endDate: '',
      department: '',
    });
    dispatch(getAllAttendance({}));
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>All Employees Attendance</h1>
        <p>View and filter attendance records for all employees</p>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">🔍 Filters</h3>
        </div>
        <form onSubmit={handleSearch}>
          <div className="filter-bar">
            <input
              type="text"
              name="employeeId"
              placeholder="Employee ID"
              value={filters.employeeId}
              onChange={handleFilterChange}
            />

            <select
              name="department"
              value={filters.department}
              onChange={handleFilterChange}
            >
              <option value="">All Departments</option>
              <option value="Engineering">Engineering</option>
              <option value="Marketing">Marketing</option>
              <option value="Sales">Sales</option>
              <option value="HR">HR</option>
              <option value="Finance">Finance</option>
            </select>

            <select
              name="status"
              value={filters.status}
              onChange={handleFilterChange}
            >
              <option value="">All Status</option>
              <option value="present">Present</option>
              <option value="absent">Absent</option>
              <option value="late">Late</option>
              <option value="half-day">Half Day</option>
            </select>

            <input
              type="date"
              name="startDate"
              placeholder="Start Date"
              value={filters.startDate}
              onChange={handleFilterChange}
            />

            <input
              type="date"
              name="endDate"
              placeholder="End Date"
              value={filters.endDate}
              onChange={handleFilterChange}
            />

            <button type="submit" className="btn btn-primary">
              Search
            </button>

            <button type="button" className="btn btn-secondary" onClick={handleReset}>
              Reset
            </button>
          </div>
        </form>
      </div>

      {/* Attendance Table */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">📋 Attendance Records</h3>
          <span style={{ color: '#666', fontSize: '14px' }}>
            Total: {attendance ? attendance.length : 0} records
          </span>
        </div>

        {isLoading ? (
          <div className="loading">
            <div className="spinner"></div>
            <p>Loading attendance...</p>
          </div>
        ) : attendance && attendance.length > 0 ? (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Employee ID</th>
                  <th>Name</th>
                  <th>Department</th>
                  <th>Date</th>
                  <th>Check In</th>
                  <th>Check Out</th>
                  <th>Total Hours</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {attendance.map((record) => (
                  <tr key={record._id}>
                    <td>{record.userId.employeeId}</td>
                    <td>{record.userId.name}</td>
                    <td>{record.userId.department}</td>
                    <td>{new Date(record.date).toLocaleDateString()}</td>
                    <td>{new Date(record.checkInTime).toLocaleTimeString()}</td>
                    <td>
                      {record.checkOutTime
                        ? new Date(record.checkOutTime).toLocaleTimeString()
                        : 'Not checked out'}
                    </td>
                    <td>{record.totalHours} hrs</td>
                    <td>
                      <span className={`status-badge ${record.status}`}>
                        {record.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-state-icon">📭</div>
            <h3>No Records Found</h3>
            <p>No attendance records match your search criteria</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AllAttendance;
