import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getEmployeeDashboard } from '../redux/attendanceSlice';

const EmployeeDashboard = () => {
  const dispatch = useDispatch();
  const { dashboard, isLoading } = useSelector((state) => state.attendance);

  useEffect(() => {
    dispatch(getEmployeeDashboard());
  }, [dispatch]);

  if (isLoading || !dashboard) {
    return (
      <div className="loading">
        <div className="spinner"></div>
        <p>Loading dashboard...</p>
      </div>
    );
  }

  const { todayStatus, monthlyStats, recentAttendance } = dashboard;

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Employee Dashboard</h1>
        <p>Welcome back! Here's your attendance overview</p>
      </div>

      {/* Today's Status */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Today's Status</h3>
        </div>
        {todayStatus ? (
          <div style={{ padding: '20px', background: '#f0fff4', borderRadius: '8px' }}>
            <p style={{ fontSize: '18px', fontWeight: '600', color: '#059669', marginBottom: '8px' }}>
              ✓ Checked In
            </p>
            <p style={{ color: '#666', marginBottom: '4px' }}>
              Check In: {new Date(todayStatus.checkInTime).toLocaleTimeString()}
            </p>
            {todayStatus.checkOutTime && (
              <p style={{ color: '#666', marginBottom: '4px' }}>
                Check Out: {new Date(todayStatus.checkOutTime).toLocaleTimeString()}
              </p>
            )}
            <p style={{ color: '#666' }}>
              Status: <span className={`status-badge ${todayStatus.status}`}>{todayStatus.status}</span>
            </p>
            {todayStatus.totalHours > 0 && (
              <p style={{ color: '#666', marginTop: '4px' }}>
                Total Hours: {todayStatus.totalHours} hours
              </p>
            )}
          </div>
        ) : (
          <div style={{ padding: '20px', background: '#fef3c7', borderRadius: '8px' }}>
            <p style={{ fontSize: '18px', fontWeight: '600', color: '#d97706' }}>
              ⚠ Not Checked In
            </p>
            <p style={{ color: '#666' }}>You haven't checked in today yet</p>
          </div>
        )}
      </div>

      {/* Monthly Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Present Days</span>
            <div className="stat-icon success">✓</div>
          </div>
          <h2 className="stat-value">{monthlyStats.present}</h2>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Late Arrivals</span>
            <div className="stat-icon warning">⏰</div>
          </div>
          <h2 className="stat-value">{monthlyStats.late}</h2>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Half Days</span>
            <div className="stat-icon warning">📅</div>
          </div>
          <h2 className="stat-value">{monthlyStats.halfDay}</h2>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Total Hours</span>
            <div className="stat-icon info">⏱</div>
          </div>
          <h2 className="stat-value">{monthlyStats.totalHours}</h2>
        </div>
      </div>

      {/* Recent Attendance */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Recent Attendance (Last 7 Days)</h3>
        </div>
        {recentAttendance && recentAttendance.length > 0 ? (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Check In</th>
                  <th>Check Out</th>
                  <th>Total Hours</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {recentAttendance.map((record) => (
                  <tr key={record._id}>
                    <td>{new Date(record.date).toLocaleDateString()}</td>
                    <td>{new Date(record.checkInTime).toLocaleTimeString()}</td>
                    <td>
                      {record.checkOutTime
                        ? new Date(record.checkOutTime).toLocaleTimeString()
                        : 'Not checked out'}
                    </td>
                    <td>{record.totalHours} hrs</td>
                    <td>
                      <span className={`status-badge ${record.status}`}>
                        {record.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-state-icon">📭</div>
            <h3>No Recent Attendance</h3>
            <p>Your recent attendance records will appear here</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmployeeDashboard;
