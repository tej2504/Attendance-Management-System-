import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getManagerDashboard } from '../redux/attendanceSlice';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const ManagerDashboard = () => {
  const dispatch = useDispatch();
  const { dashboard, isLoading } = useSelector((state) => state.attendance);

  useEffect(() => {
    dispatch(getManagerDashboard());
  }, [dispatch]);

  if (isLoading || !dashboard) {
    return (
      <div className="loading">
        <div className="spinner"></div>
        <p>Loading dashboard...</p>
      </div>
    );
  }

  const { totalEmployees, todayStats, absentEmployees, lateArrivals, weeklyTrend, departmentStats } = dashboard;

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Manager Dashboard</h1>
        <p>Team attendance overview and analytics</p>
      </div>

      {/* Today's Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Total Employees</span>
            <div className="stat-icon info">👥</div>
          </div>
          <h2 className="stat-value">{totalEmployees}</h2>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Present Today</span>
            <div className="stat-icon success">✓</div>
          </div>
          <h2 className="stat-value">{todayStats.present}</h2>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Absent Today</span>
            <div className="stat-icon danger">✗</div>
          </div>
          <h2 className="stat-value">{todayStats.absent}</h2>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Late Arrivals</span>
            <div className="stat-icon warning">⏰</div>
          </div>
          <h2 className="stat-value">{todayStats.late}</h2>
        </div>
      </div>

      {/* Charts */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(500px, 1fr))', gap: '20px', marginBottom: '20px' }}>
        {/* Weekly Trend */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Weekly Attendance Trend</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={weeklyTrend}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="present" stroke="#10b981" strokeWidth={2} />
              <Line type="monotone" dataKey="absent" stroke="#ef4444" strokeWidth={2} />
              <Line type="monotone" dataKey="late" stroke="#f59e0b" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Department Stats */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Department-wise Attendance</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={departmentStats}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="department" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="attendance" fill="#667eea" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Absent Employees Today */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Absent Employees Today</h3>
        </div>
        {absentEmployees && absentEmployees.length > 0 ? (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Employee ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Department</th>
                </tr>
              </thead>
              <tbody>
                {absentEmployees.map((emp) => (
                  <tr key={emp._id}>
                    <td>{emp.employeeId}</td>
                    <td>{emp.name}</td>
                    <td>{emp.email}</td>
                    <td>{emp.department}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-state-icon">✓</div>
            <h3>All Present!</h3>
            <p>No employees are absent today</p>
          </div>
        )}
      </div>

      {/* Late Arrivals Today */}
      {lateArrivals && lateArrivals.length > 0 && (
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Late Arrivals Today</h3>
          </div>
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Employee ID</th>
                  <th>Name</th>
                  <th>Department</th>
                  <th>Check In Time</th>
                </tr>
              </thead>
              <tbody>
                {lateArrivals.map((record) => (
                  <tr key={record._id}>
                    <td>{record.userId.employeeId}</td>
                    <td>{record.userId.name}</td>
                    <td>{record.userId.department}</td>
                    <td>{new Date(record.checkInTime).toLocaleTimeString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManagerDashboard;
