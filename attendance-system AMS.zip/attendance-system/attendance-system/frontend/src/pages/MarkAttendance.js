import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { checkIn, checkOut, getTodayAttendance, reset } from '../redux/attendanceSlice';

const MarkAttendance = () => {
  const dispatch = useDispatch();
  const { todayAttendance, isLoading, isSuccess, isError, message } = useSelector(
    (state) => state.attendance
  );

  const [alert, setAlert] = useState(null);

  useEffect(() => {
    dispatch(getTodayAttendance());
  }, [dispatch]);

  useEffect(() => {
    if (isSuccess) {
      setAlert({ type: 'success', message: 'Attendance marked successfully!' });
      dispatch(getTodayAttendance());
      setTimeout(() => {
        setAlert(null);
        dispatch(reset());
      }, 3000);
    }

    if (isError) {
      setAlert({ type: 'error', message: message });
      setTimeout(() => {
        setAlert(null);
        dispatch(reset());
      }, 3000);
    }
  }, [isSuccess, isError, message, dispatch]);

  const handleCheckIn = () => {
    dispatch(checkIn());
  };

  const handleCheckOut = () => {
    dispatch(checkOut());
  };

  const getCurrentTime = () => {
    return new Date().toLocaleTimeString();
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Mark Attendance</h1>
        <p>Check in and check out for the day</p>
      </div>

      {alert && (
        <div className={`alert alert-${alert.type}`}>
          {alert.message}
        </div>
      )}

      <div className="card" style={{ maxWidth: '600px' }}>
        <div style={{ textAlign: 'center', padding: '20px' }}>
          <div style={{ fontSize: '48px', marginBottom: '20px' }}>⏰</div>
          <h2 style={{ marginBottom: '10px', color: '#333' }}>Current Time</h2>
          <p style={{ fontSize: '32px', fontWeight: '700', color: '#667eea', marginBottom: '30px' }}>
            {getCurrentTime()}
          </p>

          {todayAttendance ? (
            <div>
              <div style={{ background: '#f0fff4', padding: '20px', borderRadius: '12px', marginBottom: '20px' }}>
                <h3 style={{ color: '#059669', marginBottom: '16px' }}>✓ Already Checked In</h3>
                <div style={{ textAlign: 'left', color: '#666' }}>
                  <p style={{ marginBottom: '8px' }}>
                    <strong>Check In Time:</strong> {new Date(todayAttendance.checkInTime).toLocaleTimeString()}
                  </p>
                  {todayAttendance.checkOutTime && (
                    <>
                      <p style={{ marginBottom: '8px' }}>
                        <strong>Check Out Time:</strong> {new Date(todayAttendance.checkOutTime).toLocaleTimeString()}
                      </p>
                      <p style={{ marginBottom: '8px' }}>
                        <strong>Total Hours:</strong> {todayAttendance.totalHours} hours
                      </p>
                    </>
                  )}
                  <p style={{ marginBottom: '8px' }}>
                    <strong>Status:</strong> <span className={`status-badge ${todayAttendance.status}`}>
                      {todayAttendance.status}
                    </span>
                  </p>
                </div>
              </div>

              {!todayAttendance.checkOutTime && (
                <button
                  className="btn btn-danger"
                  onClick={handleCheckOut}
                  disabled={isLoading}
                  style={{ fontSize: '18px', padding: '16px 48px' }}
                >
                  {isLoading ? 'Processing...' : 'Check Out'}
                </button>
              )}

              {todayAttendance.checkOutTime && (
                <div style={{ background: '#fef3c7', padding: '16px', borderRadius: '8px', color: '#92400e' }}>
                  <strong>You have already checked out for today!</strong>
                </div>
              )}
            </div>
          ) : (
            <div>
              <div style={{ background: '#fef3c7', padding: '20px', borderRadius: '12px', marginBottom: '20px' }}>
                <h3 style={{ color: '#d97706', marginBottom: '8px' }}>⚠ Not Checked In</h3>
                <p style={{ color: '#666', margin: 0 }}>Please check in to mark your attendance for today</p>
              </div>

              <button
                className="btn btn-success"
                onClick={handleCheckIn}
                disabled={isLoading}
                style={{ fontSize: '18px', padding: '16px 48px' }}
              >
                {isLoading ? 'Processing...' : 'Check In'}
              </button>
            </div>
          )}
        </div>

        <div style={{ borderTop: '1px solid #f0f0f0', padding: '20px', background: '#f9fafb', borderRadius: '0 0 12px 12px' }}>
          <h4 style={{ marginBottom: '12px', color: '#333' }}>📋 Guidelines</h4>
          <ul style={{ color: '#666', fontSize: '14px', lineHeight: '1.8', paddingLeft: '20px' }}>
            <li>Standard work hours: 9:00 AM - 6:00 PM</li>
            <li>Check-in after 9:30 AM will be marked as "Late"</li>
            <li>Less than 4 hours will be marked as "Half Day"</li>
            <li>You can only check in/out once per day</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default MarkAttendance;
