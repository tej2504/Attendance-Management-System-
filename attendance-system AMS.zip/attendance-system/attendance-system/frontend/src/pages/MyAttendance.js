import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getMyHistory, getMySummary } from '../redux/attendanceSlice';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

const MyAttendance = () => {
  const dispatch = useDispatch();
  const { attendance, summary, isLoading } = useSelector((state) => state.attendance);

  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [viewMode, setViewMode] = useState('calendar'); // 'calendar' or 'table'

  useEffect(() => {
    dispatch(getMyHistory({ month: selectedMonth, year: selectedYear }));
    dispatch(getMySummary({ month: selectedMonth, year: selectedYear }));
  }, [dispatch, selectedMonth, selectedYear]);

  const getAttendanceForDate = (date) => {
    return attendance.find((record) => {
      const recordDate = new Date(record.date);
      return (
        recordDate.toDateString() === date.toDateString()
      );
    });
  };

  const tileClassName = ({ date, view }) => {
    if (view === 'month') {
      const record = getAttendanceForDate(date);
      if (record) {
        return `calendar-day ${record.status}`;
      }
    }
    return null;
  };

  const tileContent = ({ date, view }) => {
    if (view === 'month') {
      const record = getAttendanceForDate(date);
      if (record) {
        return <div className={`calendar-indicator ${record.status}`}></div>;
      }
    }
    return null;
  };

  const handleMonthChange = (e) => {
    setSelectedMonth(parseInt(e.target.value));
  };

  const handleYearChange = (e) => {
    setSelectedYear(parseInt(e.target.value));
  };

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYear - 2 + i);
  const months = [
    { value: 1, label: 'January' },
    { value: 2, label: 'February' },
    { value: 3, label: 'March' },
    { value: 4, label: 'April' },
    { value: 5, label: 'May' },
    { value: 6, label: 'June' },
    { value: 7, label: 'July' },
    { value: 8, label: 'August' },
    { value: 9, label: 'September' },
    { value: 10, label: 'October' },
    { value: 11, label: 'November' },
    { value: 12, label: 'December' },
  ];

  if (isLoading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
        <p>Loading attendance...</p>
      </div>
    );
  }

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>My Attendance History</h1>
        <p>View your attendance records and statistics</p>
      </div>

      {/* Monthly Summary */}
      {summary && (
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-card-header">
              <span className="stat-card-title">Working Days</span>
              <div className="stat-icon info">📅</div>
            </div>
            <h2 className="stat-value">{summary.workingDays}</h2>
          </div>

          <div className="stat-card">
            <div className="stat-card-header">
              <span className="stat-card-title">Present</span>
              <div className="stat-icon success">✓</div>
            </div>
            <h2 className="stat-value">{summary.present}</h2>
          </div>

          <div className="stat-card">
            <div className="stat-card-header">
              <span className="stat-card-title">Late</span>
              <div className="stat-icon warning">⏰</div>
            </div>
            <h2 className="stat-value">{summary.late}</h2>
          </div>

          <div className="stat-card">
            <div className="stat-card-header">
              <span className="stat-card-title">Absent</span>
              <div className="stat-icon danger">✗</div>
            </div>
            <h2 className="stat-value">{summary.absent}</h2>
          </div>

          <div className="stat-card">
            <div className="stat-card-header">
              <span className="stat-card-title">Half Day</span>
              <div className="stat-icon warning">📅</div>
            </div>
            <h2 className="stat-value">{summary.halfDay}</h2>
          </div>

          <div className="stat-card">
            <div className="stat-card-header">
              <span className="stat-card-title">Total Hours</span>
              <div className="stat-icon info">⏱</div>
            </div>
            <h2 className="stat-value">{summary.totalHours}</h2>
          </div>
        </div>
      )}

      {/* Filters and View Toggle */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <div className="filter-bar">
            <select value={selectedMonth} onChange={handleMonthChange}>
              {months.map((month) => (
                <option key={month.value} value={month.value}>
                  {month.label}
                </option>
              ))}
            </select>

            <select value={selectedYear} onChange={handleYearChange}>
              {years.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </div>

          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              className={`btn ${viewMode === 'calendar' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setViewMode('calendar')}
            >
              📅 Calendar
            </button>
            <button
              className={`btn ${viewMode === 'table' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setViewMode('table')}
            >
              📋 Table
            </button>
          </div>
        </div>

        {viewMode === 'calendar' ? (
          <div>
            <div className="calendar-container">
              <Calendar
                value={new Date(selectedYear, selectedMonth - 1)}
                tileClassName={tileClassName}
                tileContent={tileContent}
                onActiveStartDateChange={({ activeStartDate }) => {
                  setSelectedMonth(activeStartDate.getMonth() + 1);
                  setSelectedYear(activeStartDate.getFullYear());
                }}
              />
            </div>

            <div style={{ marginTop: '20px', display: 'flex', gap: '20px', flexWrap: 'wrap', justifyContent: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '16px', height: '16px', borderRadius: '50%', background: '#10b981' }}></div>
                <span>Present</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '16px', height: '16px', borderRadius: '50%', background: '#f59e0b' }}></div>
                <span>Late</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '16px', height: '16px', borderRadius: '50%', background: '#f97316' }}></div>
                <span>Half Day</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '16px', height: '16px', borderRadius: '50%', background: '#ef4444' }}></div>
                <span>Absent</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="table-container">
            {attendance && attendance.length > 0 ? (
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Check In</th>
                    <th>Check Out</th>
                    <th>Total Hours</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {attendance.map((record) => (
                    <tr key={record._id}>
                      <td>{new Date(record.date).toLocaleDateString()}</td>
                      <td>{new Date(record.checkInTime).toLocaleTimeString()}</td>
                      <td>
                        {record.checkOutTime
                          ? new Date(record.checkOutTime).toLocaleTimeString()
                          : 'Not checked out'}
                      </td>
                      <td>{record.totalHours} hrs</td>
                      <td>
                        <span className={`status-badge ${record.status}`}>
                          {record.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="empty-state">
                <div className="empty-state-icon">📭</div>
                <h3>No Attendance Records</h3>
                <p>No attendance records found for the selected period</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyAttendance;
