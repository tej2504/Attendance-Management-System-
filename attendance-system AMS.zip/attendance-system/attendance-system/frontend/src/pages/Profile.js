import React from 'react';
import { useSelector } from 'react-redux';

const Profile = () => {
  const { user } = useSelector((state) => state.auth);

  if (!user) {
    return null;
  }

  const getInitials = (name) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Profile</h1>
        <p>Your account information</p>
      </div>

      <div className="profile-card">
        <div className="profile-header">
          <div className="profile-avatar">{getInitials(user.name)}</div>
          <h2 style={{ marginBottom: '8px' }}>{user.name}</h2>
          <span className="user-badge">{user.role}</span>
        </div>

        <div className="profile-info">
          <div className="info-row">
            <span className="info-label">Employee ID</span>
            <span className="info-value">{user.employeeId}</span>
          </div>

          <div className="info-row">
            <span className="info-label">Email</span>
            <span className="info-value">{user.email}</span>
          </div>

          <div className="info-row">
            <span className="info-label">Department</span>
            <span className="info-value">{user.department}</span>
          </div>

          <div className="info-row">
            <span className="info-label">Role</span>
            <span className="info-value" style={{ textTransform: 'capitalize' }}>
              {user.role}
            </span>
          </div>

          <div className="info-row">
            <span className="info-label">Member Since</span>
            <span className="info-value">
              {new Date(user.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>

      <div className="card" style={{ maxWidth: '600px' }}>
        <div className="card-header">
          <h3 className="card-title">ℹ️ Account Information</h3>
        </div>
        <div style={{ color: '#666', fontSize: '14px', lineHeight: '1.8' }}>
          <p style={{ marginBottom: '12px' }}>
            This is your account profile. Your information is used to track attendance and generate reports.
          </p>
          <p style={{ marginBottom: '12px' }}>
            If you need to update any information, please contact your HR department or system administrator.
          </p>
          <p style={{ marginBottom: '0' }}>
            <strong>Security Tip:</strong> Keep your login credentials secure and don't share them with anyone.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Profile;
