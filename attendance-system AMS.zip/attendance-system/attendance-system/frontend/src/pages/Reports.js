import React, { useState } from 'react';
import api from '../services/api';

const Reports = () => {
  const [filters, setFilters] = useState({
    employeeId: '',
    startDate: '',
    endDate: '',
  });

  const [isExporting, setIsExporting] = useState(false);

  const handleFilterChange = (e) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value,
    });
  };

  const handleExport = async (e) => {
    e.preventDefault();
    
    if (!filters.startDate || !filters.endDate) {
      alert('Please select both start and end dates');
      return;
    }

    try {
      setIsExporting(true);
      
      const params = new URLSearchParams();
      if (filters.employeeId) params.append('employeeId', filters.employeeId);
      params.append('startDate', filters.startDate);
      params.append('endDate', filters.endDate);

      const response = await api.get(`/attendance/export?${params.toString()}`, {
        responseType: 'blob',
      });

      // Create download link
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `attendance-report-${Date.now()}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();

      alert('Report exported successfully!');
    } catch (error) {
      alert(error.response?.data?.message || 'Failed to export report');
    } finally {
      setIsExporting(false);
    }
  };

  const handleReset = () => {
    setFilters({
      employeeId: '',
      startDate: '',
      endDate: '',
    });
  };

  // Set default date range (current month)
  const setCurrentMonth = () => {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    
    setFilters({
      ...filters,
      startDate: firstDay.toISOString().split('T')[0],
      endDate: lastDay.toISOString().split('T')[0],
    });
  };

  const setLastMonth = () => {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastDay = new Date(now.getFullYear(), now.getMonth(), 0);
    
    setFilters({
      ...filters,
      startDate: firstDay.toISOString().split('T')[0],
      endDate: lastDay.toISOString().split('T')[0],
    });
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Attendance Reports</h1>
        <p>Generate and export attendance reports</p>
      </div>

      <div className="card" style={{ maxWidth: '800px' }}>
        <div className="card-header">
          <h3 className="card-title">📊 Export Attendance Report</h3>
        </div>

        <form onSubmit={handleExport}>
          <div className="form-group">
            <label htmlFor="employeeId">Employee ID (Optional)</label>
            <input
              type="text"
              id="employeeId"
              name="employeeId"
              value={filters.employeeId}
              onChange={handleFilterChange}
              placeholder="Leave empty for all employees"
            />
            <small style={{ color: '#666', fontSize: '12px', marginTop: '4px', display: 'block' }}>
              Enter specific employee ID or leave empty to export all employees
            </small>
          </div>

          <div className="form-group">
            <label htmlFor="startDate">Start Date</label>
            <input
              type="date"
              id="startDate"
              name="startDate"
              value={filters.startDate}
              onChange={handleFilterChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="endDate">End Date</label>
            <input
              type="date"
              id="endDate"
              name="endDate"
              value={filters.endDate}
              onChange={handleFilterChange}
              required
            />
          </div>

          <div style={{ display: 'flex', gap: '12px', marginBottom: '20px' }}>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={setCurrentMonth}
            >
              Current Month
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={setLastMonth}
            >
              Last Month
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={handleReset}
            >
              Reset
            </button>
          </div>

          <button
            type="submit"
            className="btn btn-success"
            disabled={isExporting}
            style={{ width: '100%' }}
          >
            {isExporting ? '⏳ Exporting...' : '📥 Export to CSV'}
          </button>
        </form>

        <div style={{ marginTop: '30px', padding: '20px', background: '#f9fafb', borderRadius: '8px' }}>
          <h4 style={{ marginBottom: '12px', color: '#333' }}>📋 Report Information</h4>
          <ul style={{ color: '#666', fontSize: '14px', lineHeight: '1.8', paddingLeft: '20px' }}>
            <li>The report will be exported in CSV format</li>
            <li>It includes: Employee ID, Name, Email, Department, Date, Check In/Out times, Total Hours, and Status</li>
            <li>You can open the CSV file in Excel, Google Sheets, or any spreadsheet application</li>
            <li>Leave Employee ID empty to export data for all employees</li>
            <li>Select a date range to filter the records</li>
          </ul>
        </div>
      </div>

      <div className="card" style={{ maxWidth: '800px' }}>
        <div className="card-header">
          <h3 className="card-title">📈 Available Reports</h3>
        </div>

        <div style={{ display: 'grid', gap: '16px' }}>
          <div style={{ padding: '20px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
            <h4 style={{ color: '#333', marginBottom: '8px' }}>📊 Attendance Summary Report</h4>
            <p style={{ color: '#666', fontSize: '14px', marginBottom: '12px' }}>
              Complete attendance records with check-in/out times and status for selected period
            </p>
            <span style={{ color: '#667eea', fontSize: '12px', fontWeight: '600' }}>CSV Export Available</span>
          </div>

          <div style={{ padding: '20px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
            <h4 style={{ color: '#333', marginBottom: '8px' }}>👥 Employee-wise Report</h4>
            <p style={{ color: '#666', fontSize: '14px', marginBottom: '12px' }}>
              Filter by specific employee to get their individual attendance history
            </p>
            <span style={{ color: '#667eea', fontSize: '12px', fontWeight: '600' }}>CSV Export Available</span>
          </div>

          <div style={{ padding: '20px', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
            <h4 style={{ color: '#333', marginBottom: '8px' }}>📅 Date Range Report</h4>
            <p style={{ color: '#666', fontSize: '14px', marginBottom: '12px' }}>
              Generate reports for any custom date range for analytics and payroll processing
            </p>
            <span style={{ color: '#667eea', fontSize: '12px', fontWeight: '600' }}>CSV Export Available</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
