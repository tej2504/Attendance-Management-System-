import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getTodayTeamStatus } from '../redux/attendanceSlice';

const TeamCalendar = () => {
  const dispatch = useDispatch();
  const { dashboard, isLoading } = useSelector((state) => state.attendance);

  useEffect(() => {
    dispatch(getTodayTeamStatus());
  }, [dispatch]);

  if (isLoading || !dashboard) {
    return (
      <div className="loading">
        <div className="spinner"></div>
        <p>Loading team status...</p>
      </div>
    );
  }

  const { totalEmployees, present, absent, lateArrivals, attendanceList, absentEmployeesList } = dashboard;

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Team Calendar</h1>
        <p>Real-time view of today's team attendance</p>
      </div>

      {/* Today's Overview */}
      <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Total Employees</span>
            <div className="stat-icon info">👥</div>
          </div>
          <h2 className="stat-value">{totalEmployees}</h2>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Present Today</span>
            <div className="stat-icon success">✓</div>
          </div>
          <h2 className="stat-value">{present}</h2>
          <p style={{ color: '#10b981', fontSize: '14px', marginTop: '4px' }}>
            {((present / totalEmployees) * 100).toFixed(1)}% attendance
          </p>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Absent Today</span>
            <div className="stat-icon danger">✗</div>
          </div>
          <h2 className="stat-value">{absent}</h2>
          <p style={{ color: '#ef4444', fontSize: '14px', marginTop: '4px' }}>
            {((absent / totalEmployees) * 100).toFixed(1)}% absent
          </p>
        </div>

        <div className="stat-card">
          <div className="stat-card-header">
            <span className="stat-card-title">Late Arrivals</span>
            <div className="stat-icon warning">⏰</div>
          </div>
          <h2 className="stat-value">{lateArrivals}</h2>
        </div>
      </div>

      {/* Present Employees */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">✓ Present Employees ({attendanceList?.length || 0})</h3>
        </div>
        {attendanceList && attendanceList.length > 0 ? (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Employee ID</th>
                  <th>Name</th>
                  <th>Department</th>
                  <th>Check In Time</th>
                  <th>Check Out Time</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {attendanceList.map((record) => (
                  <tr key={record._id}>
                    <td>{record.userId.employeeId}</td>
                    <td>{record.userId.name}</td>
                    <td>{record.userId.department}</td>
                    <td>{new Date(record.checkInTime).toLocaleTimeString()}</td>
                    <td>
                      {record.checkOutTime
                        ? new Date(record.checkOutTime).toLocaleTimeString()
                        : 'Not checked out'}
                    </td>
                    <td>
                      <span className={`status-badge ${record.status}`}>
                        {record.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty-state">
            <div className="empty-state-icon">📭</div>
            <h3>No One Present</h3>
            <p>No employees have checked in today</p>
          </div>
        )}
      </div>

      {/* Absent Employees */}
      {absentEmployeesList && absentEmployeesList.length > 0 && (
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">✗ Absent Employees ({absentEmployeesList.length})</h3>
          </div>
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Employee ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Department</th>
                </tr>
              </thead>
              <tbody>
                {absentEmployeesList.map((emp) => (
                  <tr key={emp._id}>
                    <td>{emp.employeeId}</td>
                    <td>{emp.name}</td>
                    <td>{emp.email}</td>
                    <td>{emp.department}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Department-wise Breakdown */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">📊 Department-wise Attendance</h3>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '16px' }}>
          {attendanceList && (() => {
            const departments = {};
            attendanceList.forEach(record => {
              const dept = record.userId.department;
              departments[dept] = (departments[dept] || 0) + 1;
            });

            return Object.entries(departments).map(([dept, count]) => (
              <div
                key={dept}
                style={{
                  padding: '20px',
                  background: '#f9fafb',
                  borderRadius: '8px',
                  border: '1px solid #e5e7eb'
                }}
              >
                <h4 style={{ color: '#333', marginBottom: '8px' }}>{dept}</h4>
                <p style={{ fontSize: '24px', fontWeight: '700', color: '#667eea', margin: 0 }}>
                  {count} <span style={{ fontSize: '14px', fontWeight: '400', color: '#666' }}>present</span>
                </p>
              </div>
            ));
          })()}
        </div>
      </div>
    </div>
  );
};

export default TeamCalendar;
