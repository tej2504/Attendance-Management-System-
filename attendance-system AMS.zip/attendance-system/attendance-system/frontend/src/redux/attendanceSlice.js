import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../services/api';

const initialState = {
  attendance: [],
  todayAttendance: null,
  dashboard: null,
  summary: null,
  isLoading: false,
  isSuccess: false,
  isError: false,
  message: '',
};

// Check in
export const checkIn = createAsyncThunk(
  'attendance/checkIn',
  async (_, thunkAPI) => {
    try {
      const response = await api.post('/attendance/checkin');
      return response.data;
    } catch (error) {
      const message =
        error.response?.data?.message || error.message || 'Check-in failed';
      return thunkAPI.rejectWithValue(message);
    }
  }
);

// Check out
export const checkOut = createAsyncThunk(
  'attendance/checkOut',
  async (_, thunkAPI) => {
    try {
      const response = await api.post('/attendance/checkout');
      return response.data;
    } catch (error) {
      const message =
        error.response?.data?.message || error.message || 'Check-out failed';
      return thunkAPI.rejectWithValue(message);
    }
  }
);

// Get today's attendance
export const getTodayAttendance = createAsyncThunk(
  'attendance/getTodayAttendance',
  async (_, thunkAPI) => {
    try {
      const response = await api.get('/attendance/today');
      return response.data;
    } catch (error) {
      const message =
        error.response?.data?.message || error.message || 'Failed to fetch attendance';
      return thunkAPI.rejectWithValue(message);
    }
  }
);

// Get my attendance history
export const getMyHistory = createAsyncThunk(
  'attendance/getMyHistory',
  async (params, thunkAPI) => {
    try {
      const response = await api.get('/attendance/my-history', { params });
      return response.data;
    } catch (error) {
      const message =
        error.response?.data?.message || error.message || 'Failed to fetch history';
      return thunkAPI.rejectWithValue(message);
    }
  }
);

// Get my summary
export const getMySummary = createAsyncThunk(
  'attendance/getMySummary',
  async (params, thunkAPI) => {
    try {
      const response = await api.get('/attendance/my-summary', { params });
      return response.data;
    } catch (error) {
      const message =
        error.response?.data?.message || error.message || 'Failed to fetch summary';
      return thunkAPI.rejectWithValue(message);
    }
  }
);

// Get employee dashboard
export const getEmployeeDashboard = createAsyncThunk(
  'attendance/getEmployeeDashboard',
  async (_, thunkAPI) => {
    try {
      const response = await api.get('/dashboard/employee');
      return response.data;
    } catch (error) {
      const message =
        error.response?.data?.message || error.message || 'Failed to fetch dashboard';
      return thunkAPI.rejectWithValue(message);
    }
  }
);

// Get manager dashboard
export const getManagerDashboard = createAsyncThunk(
  'attendance/getManagerDashboard',
  async (_, thunkAPI) => {
    try {
      const response = await api.get('/dashboard/manager');
      return response.data;
    } catch (error) {
      const message =
        error.response?.data?.message || error.message || 'Failed to fetch dashboard';
      return thunkAPI.rejectWithValue(message);
    }
  }
);

// Get all attendance (Manager)
export const getAllAttendance = createAsyncThunk(
  'attendance/getAllAttendance',
  async (params, thunkAPI) => {
    try {
      const response = await api.get('/attendance/all', { params });
      return response.data;
    } catch (error) {
      const message =
        error.response?.data?.message || error.message || 'Failed to fetch attendance';
      return thunkAPI.rejectWithValue(message);
    }
  }
);

// Get today's team status (Manager)
export const getTodayTeamStatus = createAsyncThunk(
  'attendance/getTodayTeamStatus',
  async (_, thunkAPI) => {
    try {
      const response = await api.get('/attendance/today-status');
      return response.data;
    } catch (error) {
      const message =
        error.response?.data?.message || error.message || 'Failed to fetch team status';
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const attendanceSlice = createSlice({
  name: 'attendance',
  initialState,
  reducers: {
    reset: (state) => {
      state.isLoading = false;
      state.isSuccess = false;
      state.isError = false;
      state.message = '';
    },
  },
  extraReducers: (builder) => {
    builder
      // Check in
      .addCase(checkIn.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(checkIn.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.todayAttendance = action.payload.data;
      })
      .addCase(checkIn.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.message = action.payload;
      })
      // Check out
      .addCase(checkOut.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(checkOut.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.todayAttendance = action.payload.data;
      })
      .addCase(checkOut.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.message = action.payload;
      })
      // Get today's attendance
      .addCase(getTodayAttendance.fulfilled, (state, action) => {
        state.todayAttendance = action.payload.data;
      })
      // Get my history
      .addCase(getMyHistory.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getMyHistory.fulfilled, (state, action) => {
        state.isLoading = false;
        state.attendance = action.payload.data;
      })
      .addCase(getMyHistory.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.message = action.payload;
      })
      // Get my summary
      .addCase(getMySummary.fulfilled, (state, action) => {
        state.summary = action.payload.data;
      })
      // Get employee dashboard
      .addCase(getEmployeeDashboard.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getEmployeeDashboard.fulfilled, (state, action) => {
        state.isLoading = false;
        state.dashboard = action.payload.data;
      })
      .addCase(getEmployeeDashboard.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.message = action.payload;
      })
      // Get manager dashboard
      .addCase(getManagerDashboard.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getManagerDashboard.fulfilled, (state, action) => {
        state.isLoading = false;
        state.dashboard = action.payload.data;
      })
      .addCase(getManagerDashboard.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.message = action.payload;
      })
      // Get all attendance
      .addCase(getAllAttendance.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getAllAttendance.fulfilled, (state, action) => {
        state.isLoading = false;
        state.attendance = action.payload.data;
      })
      .addCase(getAllAttendance.rejected, (state, action) => {
        state.isLoading = false;
        state.isError = true;
        state.message = action.payload;
      })
      // Get today's team status
      .addCase(getTodayTeamStatus.fulfilled, (state, action) => {
        state.dashboard = action.payload.data;
      });
  },
});

export const { reset } = attendanceSlice.actions;
export default attendanceSlice.reducer;
