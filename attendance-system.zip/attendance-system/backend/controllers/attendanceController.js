const Attendance = require('../models/Attendance');
const User = require('../models/User');
const { Parser } = require('json2csv');

// To get start and end of day
const getStartAndEndOfDay = (date) => {
  const start = new Date(date);
  start.setHours(0, 0, 0, 0);
  const end = new Date(date);
  end.setHours(23, 59, 59, 999);
  return { start, end };
};

// Function to calculate status based on check-in time
const calculateStatus = (checkInTime) => {
  const hours = checkInTime.getHours();
  const minutes = checkInTime.getMinutes();
  
  // If check-in is after 9:30 AM then late
  if (hours > 9 || (hours === 9 && minutes > 30)) {
    return 'late';
  }
  return 'present';
};

// Function to calculate total hours
const calculateTotalHours = (checkInTime, checkOutTime) => {
  if (!checkOutTime) return 0;
  const diff = checkOutTime - checkInTime;
  return Number((diff / (1000 * 60 * 60)).toFixed(2)); // Convert to hours
};

// @desc    Check in
// @route   POST /api/attendance/checkin
// @access  Private (Employee)
exports.checkIn = async (req, res) => {
  try {
    const today = new Date();
    const { start, end } = getStartAndEndOfDay(today);

    // Check if already checked in today
    const existingAttendance = await Attendance.findOne({
      userId: req.user._id,
      date: { $gte: start, $lte: end }
    });

    if (existingAttendance) {
      return res.status(400).json({
        success: false,
        message: 'You have already checked in today'
      });
    }

    const checkInTime = new Date();
    const status = calculateStatus(checkInTime);

    const attendance = await Attendance.create({
      userId: req.user._id,
      date: today,
      checkInTime,
      status
    });

    const populatedAttendance = await Attendance.findById(attendance._id).populate('userId', 'name email employeeId department');

    res.status(201).json({
      success: true,
      data: populatedAttendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Check out
// @route   POST /api/attendance/checkout
// @access  Private (Employee)
exports.checkOut = async (req, res) => {
  try {
    const today = new Date();
    const { start, end } = getStartAndEndOfDay(today);

    // Todays attendance
    const attendance = await Attendance.findOne({
      userId: req.user._id,
      date: { $gte: start, $lte: end }
    });

    if (!attendance) {
      return res.status(400).json({
        success: false,
        message: 'You have not checked in today'
      });
    }

    if (attendance.checkOutTime) {
      return res.status(400).json({
        success: false,
        message: 'You have already checked out today'
      });
    }

    const checkOutTime = new Date();
    const totalHours = calculateTotalHours(attendance.checkInTime, checkOutTime);

    // Update status to half-day if total hours < 4
    let status = attendance.status;
    if (totalHours < 4) {
      status = 'half-day';
    }

    attendance.checkOutTime = checkOutTime;
    attendance.totalHours = totalHours;
    attendance.status = status;
    await attendance.save();

    const populatedAttendance = await Attendance.findById(attendance._id).populate('userId', 'name email employeeId department');

    res.status(200).json({
      success: true,
      data: populatedAttendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get my attendance history
// @route   GET /api/attendance/my-history
// @access  Private (Employee)
exports.getMyHistory = async (req, res) => {
  try {
    const { month, year } = req.query;
    
    let query = { userId: req.user._id };

    // Filter by month and year
    if (month && year) {
      const startDate = new Date(year, month - 1, 1);
      const endDate = new Date(year, month, 0, 23, 59, 59, 999);
      query.date = { $gte: startDate, $lte: endDate };
    }

    const attendance = await Attendance.find(query)
      .sort({ date: -1 })
      .populate('userId', 'name email employeeId department');

    res.status(200).json({
      success: true,
      count: attendance.length,
      data: attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get my monthly summary
// @route   GET /api/attendance/my-summary
// @access  Private (Employee)
exports.getMySummary = async (req, res) => {
  try {
    const { month, year } = req.query;
    const currentDate = new Date();
    const targetMonth = month ? parseInt(month) - 1 : currentDate.getMonth();
    const targetYear = year ? parseInt(year) : currentDate.getFullYear();

    const startDate = new Date(targetYear, targetMonth, 1);
    const endDate = new Date(targetYear, targetMonth + 1, 0, 23, 59, 59, 999);

    const attendance = await Attendance.find({
      userId: req.user._id,
      date: { $gte: startDate, $lte: endDate }
    });

    // Summary
    const summary = {
      totalDays: attendance.length,
      present: attendance.filter(a => a.status === 'present').length,
      late: attendance.filter(a => a.status === 'late').length,
      halfDay: attendance.filter(a => a.status === 'half-day').length,
      absent: 0, // Will be calculated based on working days
      totalHours: attendance.reduce((sum, a) => sum + a.totalHours, 0).toFixed(2)
    };

    // Working days (excluding weekends)
    let workingDays = 0;
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      const dayOfWeek = d.getDay();
      if (dayOfWeek !== 0 && dayOfWeek !== 6) { // Not Sunday or Saturday
        workingDays++;
      }
    }

    summary.absent = workingDays - attendance.length;
    summary.workingDays = workingDays;

    res.status(200).json({
      success: true,
      data: summary
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get today's attendance status
// @route   GET /api/attendance/today
// @access  Private (Employee)
exports.getTodayStatus = async (req, res) => {
  try {
    const today = new Date();
    const { start, end } = getStartAndEndOfDay(today);

    const attendance = await Attendance.findOne({
      userId: req.user._id,
      date: { $gte: start, $lte: end }
    }).populate('userId', 'name email employeeId department');

    if (!attendance) {
  return res.status(200).json({
    success: true,
    message: "Not checked in today",
    data: null
        });
   }
 
    res.status(200).json({
      success: true,
      data: attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get all employees attendance (Manager only)
// @route   GET /api/attendance/all
// @access  Private (Manager)
exports.getAllAttendance = async (req, res) => {
  try {
    const { employeeId, status, startDate, endDate, department } = req.query;
    
    let query = {};

    // Filter by employee
    if (employeeId) {
      const user = await User.findOne({ employeeId });
      if (user) {
        query.userId = user._id;
      }
    }

    // Filter by department
    if (department) {
      const users = await User.find({ department });
      const userIds = users.map(u => u._id);
      query.userId = { $in: userIds };
    }

    // Filter by status
    if (status) {
      query.status = status;
    }

    // Filter by date range
    if (startDate && endDate) {
      query.date = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }

    const attendance = await Attendance.find(query)
      .sort({ date: -1 })
      .populate('userId', 'name email employeeId department');

    res.status(200).json({
      success: true,
      count: attendance.length,
      data: attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get specific employee attendance (Manager only)
// @route   GET /api/attendance/employee/:id
// @access  Private (Manager)
exports.getEmployeeAttendance = async (req, res) => {
  try {
    const { month, year } = req.query;
    
    let query = { userId: req.params.id };

    if (month && year) {
      const startDate = new Date(year, month - 1, 1);
      const endDate = new Date(year, month, 0, 23, 59, 59, 999);
      query.date = { $gte: startDate, $lte: endDate };
    }

    const attendance = await Attendance.find(query)
      .sort({ date: -1 })
      .populate('userId', 'name email employeeId department');

    res.status(200).json({
      success: true,
      count: attendance.length,
      data: attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get team summary (Manager only)
// @route   GET /api/attendance/summary
// @access  Private (Manager)
exports.getTeamSummary = async (req, res) => {
  try {
    const { month, year } = req.query;
    const currentDate = new Date();
    const targetMonth = month ? parseInt(month) - 1 : currentDate.getMonth();
    const targetYear = year ? parseInt(year) : currentDate.getFullYear();

    const startDate = new Date(targetYear, targetMonth, 1);
    const endDate = new Date(targetYear, targetMonth + 1, 0, 23, 59, 59, 999);

    const attendance = await Attendance.find({
      date: { $gte: startDate, $lte: endDate }
    }).populate('userId', 'name email employeeId department');

    const totalEmployees = await User.countDocuments({ role: 'employee' });

    const summary = {
      totalEmployees,
      totalPresent: attendance.filter(a => a.status === 'present').length,
      totalLate: attendance.filter(a => a.status === 'late').length,
      totalHalfDay: attendance.filter(a => a.status === 'half-day').length,
      totalAbsent: 0,
      totalHours: attendance.reduce((sum, a) => sum + a.totalHours, 0).toFixed(2)
    };

    res.status(200).json({
      success: true,
      data: summary
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Get today's status (Manager only)
// @route   GET /api/attendance/today-status
// @access  Private (Manager)
exports.getTodayTeamStatus = async (req, res) => {
  try {
    const today = new Date();
    const { start, end } = getStartAndEndOfDay(today);

    const attendance = await Attendance.find({
      date: { $gte: start, $lte: end }
    }).populate('userId', 'name email employeeId department');

    const totalEmployees = await User.countDocuments({ role: 'employee' });
    const presentEmployees = attendance.length;
    const absentEmployees = totalEmployees - presentEmployees;

    // List of absent employees
    const presentUserIds = attendance.map(a => a.userId._id.toString());
    const allEmployees = await User.find({ role: 'employee' });
    const absentEmployeesList = allEmployees.filter(
      emp => !presentUserIds.includes(emp._id.toString())
    );

    const lateArrivals = attendance.filter(a => a.status === 'late');

    res.status(200).json({
      success: true,
      data: {
        totalEmployees,
        present: presentEmployees,
        absent: absentEmployees,
        lateArrivals: lateArrivals.length,
        attendanceList: attendance,
        absentEmployeesList,
        lateArrivalsList: lateArrivals
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

// @desc    Export attendance to CSV (Manager only)
// @route   GET /api/attendance/export
// @access  Private (Manager)
exports.exportAttendance = async (req, res) => {
  try {
    const { startDate, endDate, employeeId } = req.query;
    
    let query = {};

    if (employeeId) {
      const user = await User.findOne({ employeeId });
      if (user) {
        query.userId = user._id;
      }
    }

    if (startDate && endDate) {
      query.date = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }

    const attendance = await Attendance.find(query)
      .sort({ date: -1 })
      .populate('userId', 'name email employeeId department');

    // Format data for CSV
    const csvData = attendance.map(record => ({
      'Employee ID': record.userId.employeeId,
      'Name': record.userId.name,
      'Email': record.userId.email,
      'Department': record.userId.department,
      'Date': record.date.toLocaleDateString(),
      'Check In': record.checkInTime.toLocaleTimeString(),
      'Check Out': record.checkOutTime ? record.checkOutTime.toLocaleTimeString() : 'Not checked out',
      'Total Hours': record.totalHours,
      'Status': record.status
    }));

    const parser = new Parser();
    const csv = parser.parse(csvData);

    res.header('Content-Type', 'text/csv');
    res.attachment('attendance-report.csv');
    res.send(csv);
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};
